#!/usr/bin/env node
// Generate the OMB video voice-over with your local Chatterbox server.
// No dependencies: Node 18+ only.
//
//   node generate-vo.mjs                       # all scenes
//   node generate-vo.mjs --only scene-09       # one scene (comma-separate for several)
//   node generate-vo.mjs --list-voices         # see which voices your server offers
//   node generate-vo.mjs --voice my-voice.wav --base http://127.0.0.1:4123
//
// For each scene it writes, into --out (default ./public/assets/vo):
//   scene-XX.wav            the narration
//   scene-XX.captions.json  sentence timings in Remotion's Caption format (text, startMs, endMs)
// and vo-manifest.json with every scene's duration, so the video timeline can follow the audio.
//
// It sends the same request OMB itself sends to Chatterbox: POST {base}/v1/audio/speech
// with { model, input, voice, response_format: "wav" }.

import { readFile, writeFile, mkdir } from "node:fs/promises";
import { resolve } from "node:path";

const args = parseArgs(process.argv.slice(2));
const BASE = (args.base ?? process.env.CHATTERBOX_URL ?? "http://127.0.0.1:4123").replace(/\/+$/, "");
const API = /\/v1$/i.test(BASE) ? BASE : `${BASE}/v1`;
const VOICE = args.voice ?? "default";
const MODEL = args.model ?? "chatterbox-turbo";
const OUT = resolve(args.out ?? "public/assets/vo");
const SCRIPT = resolve(args.script ?? "vo-script.json");
const PAUSE_MS = Number(args.pause ?? 300);       // silence between sentences
const LEAD_MS = Number(args.lead ?? 200);         // silence at the start and end of each scene
const MAX_CHARS = Number(args["max-chars"] ?? 280); // Chatterbox sounds best on short inputs
const PACK = Boolean(args.pack);                  // --pack: join short sentences into one request (fewer calls, coarser captions)
const ONLY = args.only ? new Set(String(args.only).split(",").map((s) => s.trim())) : null;

if (args.help) {
  console.log("Options: --base URL  --voice ID  --model ID  --out DIR  --script FILE  --only scene-01,scene-02  --pause MS  --lead MS  --max-chars N  --pack  --list-voices");
  process.exit(0);
}

if (args["list-voices"]) {
  await listVoices();
  process.exit(0);
}

const script = JSON.parse(await readFile(SCRIPT, "utf8"));
await mkdir(OUT, { recursive: true });

const manifestPath = resolve(OUT, "vo-manifest.json");
let manifest = {};
try { manifest = JSON.parse(await readFile(manifestPath, "utf8")); } catch {}

const scenes = script.scenes.filter((s) => !ONLY || ONLY.has(s.id));
if (!scenes.length) { console.error("No scenes matched --only."); process.exit(1); }

console.log(`Chatterbox: ${API}  voice: ${VOICE}  model: ${MODEL}`);
console.log(`Writing to: ${OUT}\n`);

for (const scene of scenes) {
  const chunks = chunkText(scene.text, MAX_CHARS);
  process.stdout.write(`${scene.id} (${chunks.length} parts) `);
  let fmt = null;
  const pieces = [];
  const captions = [];
  let cursorMs = LEAD_MS;

  for (const chunk of chunks) {
    const wav = parseWav(await synth(chunk));
    if (!fmt) fmt = wav.fmt;
    else if (!sameFormat(fmt, wav.fmt)) throw new Error(`${scene.id}: the server changed audio format mid-scene`);
    const ms = (wav.data.length / fmt.blockAlign / fmt.sampleRate) * 1000;
    captions.push({ text: chunk, startMs: Math.round(cursorMs), endMs: Math.round(cursorMs + ms), timestampMs: null, confidence: null });
    pieces.push(wav.data);
    cursorMs += ms + PAUSE_MS;
    process.stdout.write(".");
  }

  const silence = (ms) => Buffer.alloc(Math.round((ms / 1000) * fmt.sampleRate) * fmt.blockAlign);
  const parts = [silence(LEAD_MS)];
  pieces.forEach((p, i) => { parts.push(p); parts.push(silence(i < pieces.length - 1 ? PAUSE_MS : LEAD_MS)); });
  const pcm = Buffer.concat(parts);
  const durationMs = Math.round((pcm.length / fmt.blockAlign / fmt.sampleRate) * 1000);

  await writeFile(resolve(OUT, `${scene.id}.wav`), buildWav(fmt, pcm));
  await writeFile(resolve(OUT, `${scene.id}.captions.json`), JSON.stringify(captions, null, 2));
  manifest[scene.id] = { title: scene.title, file: `${scene.id}.wav`, durationMs, durationSec: +(durationMs / 1000).toFixed(2), voice: VOICE };
  console.log(` ${(durationMs / 1000).toFixed(1)}s`);
}

await writeFile(manifestPath, JSON.stringify(manifest, null, 2));
const total = Object.values(manifest).reduce((a, s) => a + s.durationMs, 0);
console.log(`\nDone. Total narration so far: ${Math.floor(total / 60000)}m ${Math.round((total % 60000) / 1000)}s`);
console.log(`Manifest: ${manifestPath}`);

// ---------- helpers ----------

async function synth(text, attempt = 1) {
  let res;
  try {
    res = await fetch(`${API}/audio/speech`, {
      method: "POST",
      headers: { "content-type": "application/json", accept: "audio/wav" },
      body: JSON.stringify({ model: MODEL, input: text, voice: VOICE, response_format: "wav" }),
      signal: AbortSignal.timeout(180_000),
    });
  } catch (e) {
    if (attempt < 3) return synth(text, attempt + 1);
    throw new Error(`Couldn't reach Chatterbox at ${API}. Is the server running? (${e.message})`);
  }
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    if (attempt < 3 && res.status >= 500) return synth(text, attempt + 1);
    throw new Error(`Chatterbox answered ${res.status}: ${body.slice(0, 300)}`);
  }
  const type = (res.headers.get("content-type") ?? "").toLowerCase();
  if (type.includes("mpeg") || type.includes("mp3")) throw new Error("The server returned MP3. Configure it to return WAV (response_format: wav).");
  return Buffer.from(await res.arrayBuffer());
}

async function listVoices() {
  for (const path of ["/models", "/audio/voices"]) {
    try {
      const res = await fetch(`${API}${path}`, { signal: AbortSignal.timeout(10_000) });
      if (res.ok) { console.log(`${API}${path}:`); console.log(JSON.stringify(await res.json(), null, 2)); }
    } catch (e) { console.log(`${API}${path}: ${e.message}`); }
  }
}

// Split into sentences, then pack sentences into chunks of at most maxChars.
function chunkText(text, maxChars) {
  const sentences = text.replace(/\s+/g, " ").trim().match(/[^.!?]+[.!?]+["')\]]*|[^.!?]+$/g) ?? [text];
  const out = [];
  let cur = "";
  for (const s0 of sentences) {
    const s = s0.trim();
    if (!s) continue;
    if (s.length > maxChars) {               // very long sentence: split on commas
      if (cur) { out.push(cur); cur = ""; }
      let part = "";
      for (const piece of s.split(/(?<=,)\s+/)) {
        if ((part + " " + piece).trim().length > maxChars && part) { out.push(part.trim()); part = piece; }
        else part = (part + " " + piece).trim();
      }
      if (part) out.push(part.trim());
      continue;
    }
    if (!PACK) { out.push(s); continue; }     // default: one sentence per request = one caption per sentence
    if ((cur + " " + s).trim().length > maxChars) { out.push(cur); cur = s; }
    else cur = (cur + " " + s).trim();
  }
  if (cur) out.push(cur);
  return out;
}

function parseWav(buf) {
  if (buf.toString("ascii", 0, 4) !== "RIFF" || buf.toString("ascii", 8, 12) !== "WAVE") {
    throw new Error("The server did not return a WAV file.");
  }
  let off = 12, fmt = null, data = null;
  while (off + 8 <= buf.length) {
    const id = buf.toString("ascii", off, off + 4);
    let size = buf.readUInt32LE(off + 4);
    const start = off + 8;
    if (id === "data") {
      if (size === 0 || size === 0xffffffff || start + size > buf.length) size = buf.length - start; // streamed WAVs
      data = buf.subarray(start, start + size);
      break;
    }
    if (id === "fmt ") {
      fmt = {
        audioFormat: buf.readUInt16LE(start),
        channels: buf.readUInt16LE(start + 2),
        sampleRate: buf.readUInt32LE(start + 4),
        blockAlign: buf.readUInt16LE(start + 12),
        bitsPerSample: buf.readUInt16LE(start + 14),
      };
    }
    off = start + size + (size % 2);
  }
  if (!fmt || !data) throw new Error("Could not read the WAV returned by the server.");
  data = data.subarray(0, data.length - (data.length % fmt.blockAlign));
  return { fmt, data };
}

function sameFormat(a, b) {
  return a.audioFormat === b.audioFormat && a.channels === b.channels && a.sampleRate === b.sampleRate && a.bitsPerSample === b.bitsPerSample;
}

function buildWav(fmt, pcm) {
  const h = Buffer.alloc(44);
  h.write("RIFF", 0); h.writeUInt32LE(36 + pcm.length, 4); h.write("WAVE", 8);
  h.write("fmt ", 12); h.writeUInt32LE(16, 16); h.writeUInt16LE(fmt.audioFormat, 20);
  h.writeUInt16LE(fmt.channels, 22); h.writeUInt32LE(fmt.sampleRate, 24);
  h.writeUInt32LE(fmt.sampleRate * fmt.blockAlign, 28); h.writeUInt16LE(fmt.blockAlign, 32);
  h.writeUInt16LE(fmt.bitsPerSample, 34); h.write("data", 36); h.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([h, pcm]);
}

function parseArgs(argv) {
  const o = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith("--")) continue;
    const key = a.slice(2);
    const next = argv[i + 1];
    if (next === undefined || next.startsWith("--")) o[key] = true;
    else { o[key] = next; i++; }
  }
  return o;
}
