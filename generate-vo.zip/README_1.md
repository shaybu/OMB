# OMB video voice-over, generated with your local Chatterbox

## Run it (on your Mac, with Chatterbox running)
1. Put `generate-vo.mjs` and `vo-script.json` in the root of the Remotion project.
2. Check the server and pick a voice:
   node generate-vo.mjs --list-voices
3. Try one scene first and listen:
   node generate-vo.mjs --only scene-00 --voice <voice-id>
4. Generate everything:
   node generate-vo.mjs --voice <voice-id>
   Output goes to public/assets/vo/: scene-XX.wav, scene-XX.captions.json, vo-manifest.json

## Useful options
--base http://127.0.0.1:4123   your Chatterbox address (default)
--model chatterbox-turbo        model id (default, same as OMB)
--only scene-03,scene-09        re-make just these scenes after editing their text
--pause 300                     silence between sentences, in ms
--pack                          fewer, longer requests (coarser captions)

## Editing the narration
Change the text in vo-script.json, then re-run with --only <scene-id>.
Spelled forms like "O-M-B" and "M-C-P" are there so the voice says the letters;
captions show OMB and MCP. If a word sounds wrong, respell it the same way.
